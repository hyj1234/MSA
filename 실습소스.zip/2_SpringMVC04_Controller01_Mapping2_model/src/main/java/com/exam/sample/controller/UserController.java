package com.exam.sample.controller;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.exam.sample.dto.User;

@Controller
public class UserController {

	@RequestMapping(value = "/a", method = RequestMethod.GET)
	public String a(Model model) {
		model.addAttribute("username", "홍길동");
		model.addAttribute("userage", 20);
		model.addAttribute("user", new User("이순신","1234"));
		return "a";
	}

	@RequestMapping(value = "/b", method = RequestMethod.GET)
	public String b(Map<String, User> map) {
		map.put("user", new User("이순신","1234"));
		return "b";
	}
	
	@RequestMapping(value = "/c", method = RequestMethod.GET)
	public ModelAndView c() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("c");
		mav.addObject("user", new User("이순신","1234"));
		return mav;
	}
	
}
