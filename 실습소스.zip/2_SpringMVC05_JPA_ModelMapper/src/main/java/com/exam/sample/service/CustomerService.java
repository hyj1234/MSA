package com.exam.sample.service;

import java.util.List;
import java.util.Optional;

import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;


public interface CustomerService {

	
	String createCustomer(CustomerDTO customer);
	CustomerDTO retrieveCustomer(String id);
	List<CustomerDTO> retrieveCustomerByName(String name);
	List<CustomerDTO> retrieveCustomerList();
	
	void updateCustomer(String id, CustomerDTO customer);
	void deleteCustomer(String id);
}
