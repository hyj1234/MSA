package com.exam.sample.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.exam.sample.entity.Customer;

@Repository
public class JpaCustomerRepository implements CustomerRepository {
	
	private EntityManager em;
	
	
	public JpaCustomerRepository(EntityManager em) {
		this.em = em;
	}

	@Override
	public Customer save(Customer customer) {
		em.persist(customer);
		return customer;
	}

	@Override
	public Customer findById(String id) {
		Customer customer = em.find(Customer.class, id);
		return customer;
	}

	@Override
	public List<Customer> findByName(String name) {
		String query = "select c from Customer c where c.name = :name";
		List<Customer> result = em.createQuery(query, Customer.class)
								  .setParameter("name", name)
								  .getResultList();
		System.out.println("JpaCustomerRepository.findByName:" + result);
		return result;
	}

	@Override
	public List<Customer> findAll() {
		List<Customer> result = em.createQuery("select c from Customer c", Customer.class)
								  .getResultList();
		return result;
	}

	@Override
	public void remove(String id) {
		Customer findCustomer = em.find(Customer.class, id);
		em.remove(findCustomer);
	}
}
