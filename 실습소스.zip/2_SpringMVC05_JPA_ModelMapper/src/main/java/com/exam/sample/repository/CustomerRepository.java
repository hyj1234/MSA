package com.exam.sample.repository;

import java.util.List;
import java.util.Optional;

import com.exam.sample.entity.Customer;

public interface CustomerRepository {

	Customer save(Customer customer);
	Customer findById(String id);
	List<Customer> findByName(String name);
	List<Customer> findAll();
	
	void remove(String id);
	
}
