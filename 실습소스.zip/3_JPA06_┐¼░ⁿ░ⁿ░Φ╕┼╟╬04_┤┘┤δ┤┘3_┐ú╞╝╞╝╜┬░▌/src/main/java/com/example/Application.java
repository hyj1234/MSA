
package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.MemberProduct;
import com.example.entity.Product;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 다대다 연관관계 ( M:N ) ==> N:1과 1:N으로 풀어서 구현
			
			//1. 생성
			Product p = new Product();
			p.setName("prod01");
			em.persist(p);
			
			Member m = new Member();
			m.setName("member1");
			em.persist(m);
			
			//중간테이블
			MemberProduct mp = new MemberProduct();
			mp.setMember(m); 
			mp.setProduct(p);
			em.persist(mp);
			
			MemberProduct mp2 = new MemberProduct();
			mp2.setMember(m); 
			mp2.setProduct(p);
			em.persist(mp2);

	
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

