package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team team = new  Team();
			team.setName("team1");
			Team team2 = new  Team();
			team2.setName("team2");
			
			em.persist(team);
			em.persist(team2);
			
			Member m1 = new Member("aaa1", 10, team);
			Member m2 = new Member("aaa2", 20, team2);
			Member m3 = new Member("aaa3", 30, team);
			Member m4 = new Member("aaa4", 40, team2);
			
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			em.persist(m4);
			///////////////////////////////////////////////////
			//1. Entity 타입
			 List<Member> members = em.createQuery("select m from Member m", Member.class)
					 				  .getResultList();
			 members.get(0).setAge(100);  // 영속성 컨텍스트에서 관리 되기 때문에 UPDATE 문장이 실행된다.
			
			
			//2. 내장된 Entity 타입 ==> 내부적으로 조인 SQL 실행됨. 명시적으로 join 문장 지정을 권장함
			 List<Team> teams = em.createQuery("select m.team from Member m", Team.class)
					 			.getResultList();
			 teams.forEach((r)->System.out.println(r.getName()));
			 
			 List<Team> teams2 = em.createQuery("select t from Member m join m.team t", Team.class)
			 			.getResultList();
			 teams2.forEach((r)->System.out.println(r.getName()));
			
			///////////////////////////////////////////////////
			 
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

