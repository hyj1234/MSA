package com.exam.sample.entity;

import com.exam.sample.dto.CustomerDTO;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-06-29T19:21:56+0900",
    comments = "version: 1.4.1.Final, compiler: Eclipse JDT (IDE) 3.21.0.v20200304-1404, environment: Java 1.8.0_281 (Oracle Corporation)"
)
@Component
public class CustomerMapperImpl implements CustomerMapper {

    @Override
    public CustomerDTO toCustomerDTO(Customer customer) {
        if ( customer == null ) {
            return null;
        }

        CustomerDTO customerDTO = new CustomerDTO();

        customerDTO.setId( customer.getId() );
        customerDTO.setName( customer.getName() );

        return customerDTO;
    }

    @Override
    public List<CustomerDTO> toCustomerDTOList(List<Customer> list) {
        if ( list == null ) {
            return null;
        }

        List<CustomerDTO> list1 = new ArrayList<CustomerDTO>( list.size() );
        for ( Customer customer : list ) {
            list1.add( toCustomerDTO( customer ) );
        }

        return list1;
    }
}
