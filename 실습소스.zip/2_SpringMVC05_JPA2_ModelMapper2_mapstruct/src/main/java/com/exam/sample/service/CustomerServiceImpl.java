package com.exam.sample.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;
import com.exam.sample.entity.CustomerMapper;
import com.exam.sample.repository.SpringDataJpaCustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerMapper mapper;
	
	private SpringDataJpaCustomerRepository repository;

	public CustomerServiceImpl(SpringDataJpaCustomerRepository repository) {
		this.repository = repository;
	}

	@Override
	public String createCustomer(CustomerDTO dto) {

///////////////////////////////////////////////////////////////
		Customer entity = Customer.builder()
								  .id(dto.getId())
								  .name(dto.getName())
								  .build();
		
		repository.save(entity);

		return dto.getId();
	}

	@Override
	public CustomerDTO retrieveCustomer(String id) {
////////////////////////////////////////////////////////////////
		Customer result = repository.findById(id).orElse(null);
		CustomerDTO dto = mapper.toCustomerDTO(result);
///////////////////////////////////////////////////////////////
		return dto;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerByName(String name) {
////////////////////////////////////////////////////////////////
		List<Customer> result = repository.findByName(name);
		System.out.println("CustomerServiceImpl.findByName:" + result);
		List<CustomerDTO> list = mapper.toCustomerDTOList(result);
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerList() {
////////////////////////////////////////////////////////////////
		List<Customer> result = repository.findAll();
		List<CustomerDTO> list = mapper.toCustomerDTOList(result);
		System.out.println(">>>>>>>>>>" + list);
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public void updateCustomer(String id, CustomerDTO dto) {

		Customer customer = repository.findById(id).orElse(null);
		customer.updateCustomer(dto);
	}

	@Override
	public void deleteCustomer(String id) {
		Customer findCustomer = repository.findById(id).orElse(null);
		repository.delete(findCustomer);
	}

}
