package com.exam.sample.entity;

import java.util.List;
import java.util.Optional;

import org.mapstruct.Mapper;

import com.exam.sample.dto.CustomerDTO;


@Mapper(componentModel = "spring")
public interface CustomerMapper {

	public CustomerDTO toCustomerDTO(Customer customer);
	public List<CustomerDTO> toCustomerDTOList(List<Customer> list);
}
