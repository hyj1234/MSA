package com.exam.sample.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.exam.sample.dto.CustomerDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Customer {

	@Id
	private String id;
	
	private String name;

	
	//데이터 무결성 보장하기 위해서 setter 메서드 제외하고 임의의 수정 메서드 제공
	public void updateCustomer(CustomerDTO dto) {
		if(dto.getName() != null &&  dto.getName().length() > 0 ) {
			this.name = dto.getName();
		}
	}
	
}
