
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application01_detach {

	public static void main(String[] args) {
		SpringApplication.run(Application01_detach.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {

			/*
			 *   준영속 상태로 만드는 방법
			 *   1) em.detach(entity)
			 *   	특정 엔티티만 준영속 상태로 변환
			 *   2) em.clear()
			 *      영속성 컨텍스트를 완전히 초기화
			 *   3) em.close()
			 *      영속성 컨텍스트를 종료
			 * 
			 */
	
			Member m = em.find(Member.class, 1L);
			m.setName("member3");
			
			//영속성 객체 ==> 준영속성 상태
			em.detach(m); // 준 영속성 객체이기 때문에  update문장이 실행안됨.
			
			tx.commit();
			
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

