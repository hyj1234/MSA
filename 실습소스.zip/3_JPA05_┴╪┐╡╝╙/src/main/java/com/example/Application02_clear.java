
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application02_clear {

	public static void main(String[] args) {
		SpringApplication.run(Application02_clear.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {

			/*
			 *   준영속 상태로 만드는 방법
			 *   1) em.detach(entity)
			 *   	특정 엔티티만 준영속 상태로 변환
			 *   2) em.clear()
			 *      영속성 컨텍스트를 완전히 초기화
			 *   3) em.close()
			 *      영속성 컨텍스트를 종료
			 * 
			 */
	
			Member m = em.find(Member.class, 1L);
			m.setName("member3");
			
			em.clear();  // 영속성 컨텍스트 완전 초기화

			Member m2 = em.find(Member.class, 105L);  //완전 초기화된 상태이기 때문에 SQL 문 다시 실행됨.
			
			tx.commit();
			
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

