package com.example.entity;

public enum RoleType {
	USER,ADMIN
}