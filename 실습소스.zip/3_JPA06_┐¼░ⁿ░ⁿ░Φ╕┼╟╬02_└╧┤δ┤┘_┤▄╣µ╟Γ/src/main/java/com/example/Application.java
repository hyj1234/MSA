
package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 일대다 연관관계 ( 1:N )
			//1. 데이터 저장
			Member m = new Member();
			m.setName("member1");
			em.persist(m);
			
			Member m2= new Member();
			m2.setName("member2");
			em.persist(m2);
			
			Team team = new Team();
			team.setName("teamA");
			team.getMembers().add(m);
			team.getMembers().add(m2);
			em.persist(team);
			
			//2. 단방향 조회
			Team findTeam = em.find(Team.class, team.getId());
			
			List<Member> members = findTeam.getMembers();
			for (Member member : members) {
				System.out.println("member: " + member);
			}
		
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

