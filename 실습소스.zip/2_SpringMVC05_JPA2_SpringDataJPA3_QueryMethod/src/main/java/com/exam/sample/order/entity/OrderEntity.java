package com.exam.sample.order.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


@Entity(name = "orders")
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderEntity{

	@Id
	private String orderId; //pk
	
	private String userId; //
	private String name;
	
	private String productId;
	private int quantity;
	private int unitPrice;
	private int totalPrice;
	private LocalDateTime createDate;

}
