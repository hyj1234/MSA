package com.exam.sample.order.service;


import java.util.List;

import com.exam.sample.order.dto.OrderDTO;
import com.exam.sample.order.entity.OrderEntity;


public interface OrderService {

	public List<OrderDTO> retrieveOrderByUserId(String userid);
	public List<OrderDTO> retrieveUserIdAndQuantity(String userid, int quantity);
	public List<OrderDTO>  retrieveOrderIdIn(List<String> orderIdList);
	public List<OrderDTO>  retrieveUnitPriceLessThan(int unitPrice);
	public List<OrderDTO> retrieveOrderList();
}
