package com.exam.sample.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.dto.User;

@RestController
public class UserRestController {

	@RequestMapping("/aaa2")
	public User aaa() {
		User User = new User();
		User.setUserid("홍길동");
		User.setPasswd("1234");
		return User;
	}
	
	@RequestMapping("/bbb2")
	public ArrayList<User> bbb() {
		
		ArrayList<User> list = new ArrayList<User>();
		list.add(new User("홍기동1", "20"));
		list.add(new User("홍기동2", "30"));
		list.add(new User("홍기동3", "40"));
		return list;
	}
	@RequestMapping("/ccc2")
	public HashMap<String, ArrayList<User>> cccc() {
		HashMap<String, ArrayList<User>> map 
		= new HashMap<String, ArrayList<User>>();
		ArrayList<User> list = new ArrayList<User>();
		list.add(new User("홍기동1", "20"));
		list.add(new User("홍기동2", "30"));
		list.add(new User("홍기동3", "40"));
		ArrayList<User> list2 = new ArrayList<User>();
		list2.add(new User("유관순1", "20"));
		list2.add(new User("유관순2", "30"));
		list2.add(new User("유관순3", "40"));
		
		map.put("one", list);
		map.put("two", list2);
		return map;
	}
	
}
