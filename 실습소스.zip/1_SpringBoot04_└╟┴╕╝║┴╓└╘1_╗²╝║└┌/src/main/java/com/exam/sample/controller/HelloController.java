package com.exam.sample.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.exam.sample.service.HelloService;

@Controller
public class HelloController {

	private HelloService service;
	
	// 생성자 이용하여 주입 받는다.
	public HelloController(HelloService service) {
		this.service = service;
	}
	
	@GetMapping("/hello")
	public String hello(Model m) {
		List<String> list = service.list();
		m.addAttribute("username", list.toString());
		return "main";
	}
}
