package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Application01_영속성개념Tests {

	@Test
	void contextLoads() {
	}

}
