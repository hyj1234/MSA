
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application05_flush {

	public static void main(String[] args) {
		SpringApplication.run(Application05_flush.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
		 // flush ==> 엔티티 컨텍스트의 내용을 실제 DB에 반영
	    /*
	     *   flush가 실행되는 경우
	     *   1. em.flush()
	     *   2. tx.commit()
	     *   3. JPQL 사용시
	     * 
	     */
		Member m = new Member(502L, "member 500L");
		em.persist(m);
		em.flush(); // commit() 전에 SQL이 미리 실행된다.
		System.out.println("=====================================");
		 tx.commit();	
		}catch(Exception e) {
			System.out.println("error:"  + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

