
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application04_더티체킹 {

	public static void main(String[] args) {
		SpringApplication.run(Application04_더티체킹.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
		 //영속성 컨텍스트의  변경감지(dirty checking)
		// 스냅샷 항목과 entity 항목을 비교해서 일치하지 않으면 ...
		 Member m = em.find(Member.class, 1L); 
		 m.setName("World");
		
		 tx.commit();	
		}catch(Exception e) {
			System.out.println("error:"  + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

