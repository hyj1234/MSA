
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application02_1차캐시 {

	public static void main(String[] args) {
		SpringApplication.run(Application02_1차캐시.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
		 Member m = em.find(Member.class, 1L);  // 먼저 영속성 컨텍스트에 검색하고 없으면  DB에 접근하여 Member객체를 검색하고 영속성 컨텍스트의 1차 캐시에 저장
		 System.out.println("1. " + m );
		 Member m2 = em.find(Member.class, 1L);  // 먼저 영속성 컨텍스트의 1차 캐시에서 검색, 존재하기 때문에 DB접근 안함
		 System.out.println("2. " + m2 );
		 
		 // 동일 영속성 객체 보장
		 System.out.println(m == m2);  // true 
		
		 tx.commit();	
		}catch(Exception e) {
			System.out.println("error:"  + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

