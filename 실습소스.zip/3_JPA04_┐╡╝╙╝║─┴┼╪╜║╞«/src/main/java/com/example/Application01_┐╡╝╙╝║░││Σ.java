
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application01_영속성개념 {

	public static void main(String[] args) {
		SpringApplication.run(Application01_영속성개념.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			//1. Member 객체는 비영속성 객체
			Member m = new Member();
			m.setId(101L);
			m.setName("helloJPA");
			
			//2. Member 객체는 영속성 객체 => EntityManager내의 영속성 컨텍스트에 저장
			em.persist(m);   
			//em.detach(m);   // 영속성 컨텍스트에 저장된  객체를 제거
	
			//3.  영속성 컨텍스트에 저장된 객체를 실제 DB에 반영
			tx.commit();
			
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

