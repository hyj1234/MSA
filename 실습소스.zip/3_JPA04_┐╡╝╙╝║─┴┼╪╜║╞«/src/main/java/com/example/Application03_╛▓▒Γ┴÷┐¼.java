
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application03_쓰기지연 {

	public static void main(String[] args) {
		SpringApplication.run(Application03_쓰기지연.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
		Member m = new Member(109L, "A");	
		Member m2 = new Member(108L, "B");
		
		em.persist(m);
		em.persist(m2);
		System.out.println("================배치 형태로 동작==========================");
		
		 tx.commit();	
		}catch(Exception e) {
			System.out.println("error:"  + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

