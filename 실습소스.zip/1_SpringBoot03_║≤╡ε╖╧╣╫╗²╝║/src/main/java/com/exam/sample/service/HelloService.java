package com.exam.sample.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {

	public HelloService() {
		System.out.println("HelloService 생성");
	}

}
