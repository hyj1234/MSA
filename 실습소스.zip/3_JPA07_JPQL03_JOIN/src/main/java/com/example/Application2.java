package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application2 {

	public static void main(String[] args) {
		SpringApplication.run(Application2.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team team = new  Team();
			team.setName("team1");

			Team team2 = new  Team();
			team2.setName("team2");
			
			Team team3 = new  Team();
			team3.setName("team3");
			
			em.persist(team);
			em.persist(team2);
			em.persist(team3);
			
			Member m1 = new Member("aaa1", 10, team);
			Member m2 = new Member("aaa2", 20, team2);
			Member m3 = new Member("aaa3", 30, null);
			
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			
			em.flush();
			em.clear();
			
			
			
			//2. LEFT Outer 조인
			List<Member> members2 = em.createQuery("select m from Member m left join m.team t", Member.class)
					 .getResultList();

			for (Member member : members2) {
				System.out.println("member2: " + member +"\t" + member.getTeam());
			}
			em.flush();
			em.clear();
			//3. RIGHT Outer 조인
			List<Member> members3 = em.createQuery("select m from Member m right join m.team t", Member.class)
					 .getResultList();

			for (Member member : members3) {
				System.out.println("member3: " + member +"\t" );
			}
			em.flush();
			em.clear();
			List<Team> members4 = em.createQuery("select t from Member m right join m.team t", Team.class)
					 .getResultList();

			for (Team t : members4) {
				System.out.println("team: " + t +"\t" );
			}
			 
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

