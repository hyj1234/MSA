package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team team = new  Team();
			team.setName("team1");

			Team team2 = new  Team();
			team2.setName("team2");
			
			Team team3 = new  Team();
			team3.setName("team3");
			
			em.persist(team);
			em.persist(team2);
			em.persist(team3);
			
			Member m1 = new Member("aaa1", 10, team);
			Member m2 = new Member("aaa2", 20, team2);
			Member m3 = new Member("aaa3", 30, null);
			
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			
			em.flush();
			em.clear();
			
			//1. inner 조인 ==> 내부적으로 조인 SQL 사용되고  Team에서 select 한번 더 실행됨( Lazy 변경 필요 )
			List<Member> members = em.createQuery("select m from Member m inner join m.team t", Member.class)
									 .getResultList();
			
			for (Member member : members) {
				System.out.println("member: " + member +"\t" + member.getTeam().getName());
			}
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

