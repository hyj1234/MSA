package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			
			
			Member m1 = new Member("aaa1", 50, null);
			Member m2 = new Member("aaa2", 20, null);
			Member m3 = new Member("aaa3", 30, null);
			Member m4 = new Member("aaa4", 40, null);
			Member m5 = new Member("aaa5", 13, null);
			Member m6= new Member("aaa6", 32, null);

			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			em.persist(m4);
			em.persist(m5);
			em.persist(m6);
			
			em.flush();
			em.clear();
			

			String query = "select m from Member m where m.age > (select avg(m2.age) from Member m2)";
			List<Member> members = em.createQuery(query, Member.class)
									 .getResultList();
			
			for (Member member : members) {
				System.out.println("member: " + member );
			}
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

