package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Locker;
import com.example.entity.Member;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 일대일 연관관계 ( 1:1 )
			
			//1. 엔티티 생성
			Locker locker = new Locker();
			locker.setName("locker1");
			em.persist(locker);
		
			
			Member m = new Member();
			m.setName("member1");
			em.persist(m);
			
			//양방향은 양쪽에 값 모두 저장
			m.addLocker(locker);
			
			//2. 양방향 조회
			Locker findLocker = em.find(Locker.class, locker.getId());
			
			Member findMember = findLocker.getMember();
			System.out.println("findMember: " + findMember);
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

