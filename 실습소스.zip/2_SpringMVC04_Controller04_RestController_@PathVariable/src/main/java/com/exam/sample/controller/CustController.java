package com.exam.sample.controller;


import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.dto.Customer;


@RestController
public class CustController {

	 /*
    Postman에서 사용시 복사후 실행한다.
    {"userid":"홍길동","passwd":"1234"}
 
    [{"userid":"홍길동1","passwd":"999"},
     {"userid":"홍길동2","passwd":"888"}]
 */
	@GetMapping("/cust")
	public String retriveCustList() {
		return "모든 고객 정보 리스트 반환";
	}
	
	@GetMapping("/cust/{id}")
	public String retriveCust(@PathVariable String id) {
		return id+ "에 해당하는고객 정보 반환";
	}
	
	@PostMapping("/cust")
	public String createCust(@RequestBody Customer customer ) {
		
		return customer + "에 해당하는 고객 생성";
	}
	@PostMapping("/custs")
	public String createCustList(@RequestBody List<Customer> customerList ) {
		
		return customerList + "에 해당하는 고객 생성";
	}
	@PutMapping("/cust/{id}")
	public String updateCust(@PathVariable String id, @RequestBody Customer customer) {
		
		return id+" 에 해당하는 고객정보를 " + customer +" 정보로 변경";
	}
	
	@DeleteMapping("/cust/{id}")
	public String deleteCust(@PathVariable String id) {
		return id+ "에 해당하는고객 정보 삭제";
	}
	
}
