
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member2;
import com.example.entity.Member3;
import com.example.entity.Member4;

@SpringBootApplication
public class Application2 {

	public static void main(String[] args) {
		SpringApplication.run(Application2.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
			
			
			//2.  나. strategy=GenerationType.IDENTITY  실습
			Member2 m = new Member2();
			m.setName("A");
			Member2 m2 = new Member2();
			m2.setName("A2");
			System.out.println("==========================");
			em.persist(m);
			em.persist(m2);
			System.out.println("Member.id:" + m.getId());
			System.out.println("==========================");
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

