package com.exam.sample.controller;


import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.exam.sample.dto.User;


@Controller
public class UserController {

	@RequestMapping("/")
	public String main() {
		return "index";
	}

	@CrossOrigin
	@RequestMapping(value = "/aaa", method = RequestMethod.POST)
	public @ResponseBody String xxx2(@RequestBody User dto) {
		
		System.out.println(dto);
		return "hello";
	}
	
	@RequestMapping(value = "/bbb", method = RequestMethod.POST)
	public @ResponseBody String xxx3(@RequestBody ArrayList<User> list) {
		
		System.out.println(list);
		return "hello";
	}
	
}
